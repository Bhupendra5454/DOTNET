﻿using Banking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking
{
    public  class SavingAccount:Account
    {

        public SavingAccount(double amount):base(amount) {
        
        }

        public void ShowMiniStatement()
        {

        }
    }
}
