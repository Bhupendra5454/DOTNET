﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Transflower
{
    //is a object oriented type safe function pointer
    public delegate void TransflowerOperations(string message);

}
