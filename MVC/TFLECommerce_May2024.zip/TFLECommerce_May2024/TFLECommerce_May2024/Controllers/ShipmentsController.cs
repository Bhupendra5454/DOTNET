﻿using Microsoft.AspNetCore.Mvc;

namespace TFLECommerce_May2024.Controllers
{
    public class ShipmentsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
