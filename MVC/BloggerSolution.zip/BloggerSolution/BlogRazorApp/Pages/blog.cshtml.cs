using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogRazorApp.Pages
{
    public class blogModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
