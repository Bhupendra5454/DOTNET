using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogRazorApp.Pages
{
    public class PostModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
