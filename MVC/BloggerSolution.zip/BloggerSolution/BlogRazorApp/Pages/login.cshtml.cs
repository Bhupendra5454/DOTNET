using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogRazorApp.Pages
{
    public class loginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
